import time
from PIL import Image
import numpy as np


def algo():
    current_time = int(time.time())
    generated_number = (current_time % 100) + 50
    if generated_number % 2:
        generated_number += 10
    return generated_number


img_path = "../chapter1.jpg"
img = Image.open(img_path)

img_RGB = np.array(img)
img_RGB_new = np.clip(img_RGB + algo(), 0, 255)
img = Image.fromarray(img_RGB_new.astype("uint8"), "RGB")
img.save("../chapter1out.jpg")


# sum all red channel values
red_sum = np.sum(img_RGB_new[:, :, 0])
print(red_sum)
