def separate_and_convert(s):
    # Separate numbers and letters
    number_string = ''.join([char for char in s if char.isdigit()])
    letter_string = ''.join([char for char in s if char.isalpha()])

    #convert even numbers and capital letter into ascii code  
    even_numbers_ascii = [ord(str(num)) for num in number_string if int(num) % 2 == 0]
    uppercase_letters_ascii = [ord(char) for char in letter_string if char.isupper()]

    print("Number String: ", number_string)
    print("Letter String: ", letter_string)
    print("ASCII Codes for Even Numbers: ", even_numbers_ascii)
    print("ASCII Codes for Uppercase Letters: ", uppercase_letters_ascii)

# Example
# string = '56aA1984sktr23527oaYmn145ss785fsq31Do'
# separate_and_convert(string)

s = input("Enter a string: ")
separate_and_convert(s)
