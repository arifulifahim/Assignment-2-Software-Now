def decrypt_caesar_cipher(ciphertext, shift):
    decrypted_text = []
    for char in ciphertext:
        if char.isalpha():  # Only shift alphabetic characters
            ascii_offset = 65 if char.isupper() else 97
            decrypted_char = chr((ord(char) - ascii_offset - shift) % 26 + ascii_offset)
            decrypted_text.append(decrypted_char)
        else:
            decrypted_text.append(char)  # Non-alphabetic characters remain unchanged
    return ''.join(decrypted_text)

def find_original_quote(ciphertext):
    for shift in range(1, 26):  # Test all shift key values (1 to 25)
        decrypted_text = decrypt_caesar_cipher(ciphertext, shift)
        print(f"Shift key {shift}: {decrypted_text}\n")

# Example ciphered cryptogram
ciphered_text = """
VZ FRYSVFU VZCUGVRAG NAQ N YVGGYR VAFRPHER V Z'O(R ZVFGNXRF V uZ BHG BS PBAGEBY
NAQUG GVZRF UNEQ GB IJNAQYR VS LBH PNAG LNAQYR ZR NG ZL JBEFG GURA LBH FHER NF
QRFREIR ZR NG ZL ORFG ZNEWLA ZBAEBR
"""

# Find the shift key and the original quote
find_original_quote(ciphered_text)
